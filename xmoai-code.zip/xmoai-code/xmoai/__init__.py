# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 21:44:12 2020

@author: wmont
"""

__version__ = "0.0.dev5"
