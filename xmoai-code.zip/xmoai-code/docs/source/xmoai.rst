xmoai package
=============

Subpackages
-----------

.. toctree::

   xmoai.problems
   xmoai.setup

Module contents
---------------

.. automodule:: xmoai
   :members:
   :undoc-members:
   :show-inheritance:
