xmoai.setup package
===================

Submodules
----------

xmoai.setup.configure module
----------------------------

.. automodule:: xmoai.setup.configure
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: xmoai.setup
   :members:
   :undoc-members:
   :show-inheritance:
